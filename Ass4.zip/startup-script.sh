#! /bin/bash
cd /home/amankuma
python3 mapper1.py