# -*- coding: utf-8 -*-
"""
Created on Fri Sep 20 18:31:20 2019

@author: 18123
"""
import socket
import sys
from threading import Thread


#create socket
def create_socket():
    try:
        global host
        global port
        global s
        #host= "127.0.0.1"
        port= 9889
        s=socket.socket()
        
    except socket.error as msg:
        print("SERVER_ERROR Socket Not Created\r\n"+ str(msg))
        
#Binding the socket
def bind_socket():
    try:
        print("Binding the port " + str(port))
        s.bind((socket.gethostname(),port))
        s.listen(5)
        
    except socket.error as msg:
        print("socket binding Error "+ str(msg) + "\n" + "Retrying...")
        bind_socket()

#Accepting connections while listening
def accept_connections():
    open('keyvaluepair.txt', 'a').close()  # created the file to store key-value pair
    while True:
        conn_obj,adress=s.accept() # executes until it accepts a connection
        print("Connection established with IP "+ adress[0] + " and port "+ str(adress[1]))
        try:
            Thread(target=send_commands, args=(conn_obj,)).start()
        except:
            print("Thread did not start.")
        #send_commands(conn_obj)
    conn_obj.close()
    
# Function for setting and storing key-value pair
def set_value(s):
    key=s.split(" ")[1]
    value_size=s.split(" ")[2]
    value=s.split(" ")[3].split("\n")[1]
    if int(value_size)==len(value.encode('utf-8')):
        items={}
        items.update({key:value})
        with open('keyvaluepair.txt', 'a+') as f:
            with open('keyvaluepair.txt', 'r') as f:
                temp=f.readlines()
        for i in range(0,len(temp)):
            if key == temp[i].split(",")[0]:
                #print("key already exists")
                z= "key already exists"
                return z
        with open('keyvaluepair.txt', 'a+') as f:
            for key in items.keys():
                f.write("%s,%s\n"%(key,items[key]))
            #f.close()
        success="STORED\r\n"
        return success
    else:
        fail="CLIENT_ERROR Not Stored\r\n"  #Not stored because of byte information mis-match
        return fail
    
## Function for getting value for the key
def get_value(s):
    key= s.split(" ")[1].split("\r\n")[0]
  ## Reading text file into a dictionary  
    file = open('keyvaluepair.txt' ,encoding='utf8')
    key2=[]
    value2=[]
    for line in file:
        x=line.split(",")
        key1=x[0]
        key2.append(key1)
        #print(key2)
        value1=x[1][:len(x[1])-1]
        value2.append(value1)
# Create a zip object from two lists
    zipbObj = zip(key2, value2)
    dict_file = dict(zipbObj)
    if key not in dict_file:
        res= "CLIENT_ERROR No such Key found\r\n"
        return res
    else:
        value=dict_file.get(key)
        res= "VALUE "+key+" "+ str(len(value))+ " \r\n"+value+"\r\nEND\r\n"
        return res
 

       
# Sending commands to client
def send_commands(conn_obj):
    while True: #To enable multiple sending of commands
            client_ip= str(conn_obj.recv(1024),"utf-8")  #receive input from client as string
            print(client_ip)  #debugging
            if client_ip[:3] == "set":
                sett=set_value(client_ip)
                conn_obj.send(str.encode(sett))
            elif client_ip[:3] == "get":
                get=get_value(client_ip)
                conn_obj.send(str.encode(get))
            else:
                invalid= "ERROR\r\n"
                conn_obj.send(str.encode(invalid))
                #conn_obj.send(str.encode(client_ip))  #send command to client encoded as string
            print(client_ip,end="")   #print response with end, as end prompts to next line
            
# Calling functions
def main():
    create_socket()
    bind_socket()   
    accept_connections()
    
print("Key Value Server ready")

            
        
